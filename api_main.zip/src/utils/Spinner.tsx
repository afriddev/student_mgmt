function Spinner() {
  return (
    <div className="w-screen fixed z-[9999] h-screen bg-black/50 flex items-center justify-center"> 
        
      <div className="loader "></div>
    </div>
  );
}
export default Spinner;
